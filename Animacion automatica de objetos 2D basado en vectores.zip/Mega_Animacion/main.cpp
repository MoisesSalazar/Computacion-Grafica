//Moises Alberto Salazar Machaca
//Computaci�n Gr�fica - CCOMP7-1

#include <glad/glad.h>
#include <glfw/glfw3.h>
#include <cstdlib>
#include <iostream>
#include <Windows.h>
#include <math.h>
#include <vector>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
//#include <glm/gtc/type_ptr.hpp>
extern "C" {
	__declspec(dllexport) DWORD NvOptimusEnablement = 0x00000001;
	//__declspec(dllexport) int AmdPowerXpressRequestHighPerformance = 1;
}

float velocidad = 0.01f;
bool pausar = true;
bool camino = false;
std::vector<float> manual = {0.0f,0.0f,0.0f};

void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods);
void processInput(GLFWwindow* window);

//Tam de la ventana
const unsigned int SCR_WIDTH = 1000;
const unsigned int SCR_HEIGHT = 1000;

float rValue = 0.0f, gValue = 0.0f, bValue = 0.0f;

const char* vertexShaderSource = "#version 330 core\n"
"layout (location = 0) in vec3 aPos;\n"
"out vec4 vertexColor;"
"void main()\n"
"{\n"
"   gl_Position = vec4(aPos.x, aPos.y, aPos.z, 21.0);\n"
"vertexColor = vec4(0.5, 0.0, 0.0, 1.0);"
"}\0";

const char* fragmentShaderSource = "#version 330 core\n"
"out vec4 FragColor;\n"
"in vec4 vertexColor;"
"uniform vec4 ourColor;"
"void main()\n"
"{\n"
"   FragColor = ourColor;\n"
"}\n\0";

std::vector<float> Punto_x_y(int radio,float angulo) {
	std::vector<float> p;
	p.push_back((radio * glm::cos(glm::radians(angulo))));
	p.push_back((radio * glm::sin(glm::radians(angulo))));
	return p;
}

struct Vector
{
	std::vector<float> vec;
	float k = 1;
	Vector() {
		for (int i = 0; i < 3; i++)
		{
			vec.push_back(0.0f);
		}
	}

	Vector(std::vector<float> v) {
		for (int i = 0; i < v.size(); i++)
		{
			vec.push_back(v[i]);
		}
	}

	Vector(std::vector<float> a, std::vector<float> b) {
		std::vector<float> ba;
		float ans = 0.0f;
		for (int i = 0; i < a.size(); i++)
		{
			ba.push_back(b[i] - a[i]);
		}
		//Normalizar
		for (int i = 0; i < ba.size(); i++)
		{
			ans += glm::pow(ba[i], 2);
		}
		
		ans = glm::sqrt(ans);

		for (int i = 0; i < ba.size(); i++)
		{
			vec.push_back( ba[i] / ans);
		}
	}
	void ShowVector() {
		for (int i = 0; i < vec.size(); i+=3)
		{
			std::cout << vec[i] << " " << vec[i + 1] << " " << vec[i + 2] << std::endl;
		}
	}
};

bool Comparar(std::vector<float> p_v, std::vector<float> v) {
	float error = 0.1f;
	float cercania = 0.0f;
	for (int i = 0; i < p_v.size(); i++)
	{
		cercania += glm::abs(p_v[i] - v[i]);
	}
	if (cercania <= error)
	{
		return true;
	}
	return false;
}

struct Objeto2D {
	int n_ver = 0;
	int scale = 1;
	std::vector<float> vertices;
	std::vector<float> rastro;
	std::vector<int> i_rastro;
	std::vector<int> i_p_p;
	int n_i_p_p = 0;
	std::vector<int> i_p_t;
	int n_i_p_t = 0;
	std::vector<float> centro;
	std::vector<std::vector<float>> puntos_des;
	Vector v_d;
	int j = 0;
	Objeto2D(int n_ver, int scale, float velocidad, std::vector<std::vector<float>> vec_ani) {
		
		this->scale = scale;
		this->n_ver = n_ver;
		int angulo = 360 / n_ver;

		this->vertices.push_back(0.0f);
		this->vertices.push_back(0.0f);
		this->vertices.push_back(0.0f);

		this->centro.push_back(0.0f);
		this->centro.push_back(0.0f);
		this->centro.push_back(0.0f);

		for (int i = 1; i <= n_ver; i++)
		{

			std::vector<float> p = Punto_x_y(this->scale, angulo*i);
			this->vertices.push_back(p[0]);
			this->vertices.push_back(p[1]);
			this->vertices.push_back(0);
		}
		Gen_Iter_Pri_Punto();
		Gen_Iter_Pri_Triangle();
		puntos_des = vec_ani;
		Vector v_d_1(centro, puntos_des[j]);
		this->v_d.vec = v_d_1.vec;
		this->v_d.k = velocidad;
	}
	void Gen_Iter_Pri_Punto() {
		this->n_i_p_p = vertices.size() / 3;
		for (int i = 0; i < this->n_i_p_p; i++)
		{
			this->i_p_p.push_back(i);
		}
	}
	void Gen_Iter_Pri_Triangle() {

		int j = 1;
		for (int i = 0; i < this->n_ver; i++)
		{
			this->i_p_t.push_back(j);
			this->i_p_t.push_back(0);
			if (j == this->n_ver) { j = 0; }
			this->i_p_t.push_back(j+1);
			j++;

		}
		this->n_i_p_t = i_p_t.size();
		//for (int i = 0; i < i_p_t.size(); i+=3)
		//{
		//	std::cout << i_p_t[i] << " " << i_p_t[i+1] << " " << i_p_t[i+2] << std::endl;
		//}
	}
	bool Mover(std::vector<float> des) {
		if (!Comparar(this->centro,des))
		{
			//float k = this->v_d.k;
			float k = velocidad;
			for (int i = 0; i < this->centro.size(); i += 3)
			{
				this->centro[i] += this->v_d.vec[0]*k;
				this->centro[i + 1] += this->v_d.vec[1]*k;
				this->centro[i + 2] += this->v_d.vec[2]*k;
				this->rastro.push_back(this->centro[i]);
				this->rastro.push_back(this->centro[i+1]);
				this->rastro.push_back(this->centro[i+2]);
				//if (rastro.size() > 10) {

				//	rastro.erase(rastro.begin());
				//}
				//std::cout << rastro.size() << std::endl;
			}
			for (int i = 0; i < this->vertices.size(); i += 3)
			{
				this->vertices[i] += this->v_d.vec[0]*k;
				this->vertices[i + 1] += this->v_d.vec[1]*k;
				this->vertices[i + 2] += this->v_d.vec[2]*k;
			}
			return true;
		}
		return false;
	}
	void Manual(std::vector<float> vec) {
		float k = velocidad;
		for (int i = 0; i < this->centro.size(); i += 3)
		{
			this->centro[i] += vec[0] * k;
			this->centro[i + 1] += vec[1] * k;
			this->centro[i + 2] += vec[2] * k;
			this->rastro.push_back(this->centro[i]);
			this->rastro.push_back(this->centro[i + 1]);
			this->rastro.push_back(this->centro[i + 2]);
			/*if (rastro.size() > 10) {
				rastro.erase(rastro.begin());
			}*/
		}
		for (int i = 0; i < this->vertices.size(); i += 3)
		{
			this->vertices[i] += vec[0] * k;
			this->vertices[i + 1] += vec[1] * k;
			this->vertices[i + 2] += vec[2] * k;
		}
	}
	void ShowVertices() {
		for (int i = 0; i < this->vertices.size(); i += 3)
		{
			std::cout << i+1 << " : " << vertices[i] << " " << vertices[i + 1] << " " << vertices[i + 2] << std::endl;
		}
	}
	void Animacion() {
		if (!Mover(puntos_des[j])) {
			//std::cout << "Entre" << std::endl;
			this->j += 1;
			if (this->j == puntos_des.size()) {
				this->j = 0;
			}
			Vector v_d_1(centro, puntos_des[this->j]);
			v_d.vec = v_d_1.vec;
		}
	}
	void Restaurar() {
		//std::cout << "Entre" << std::endl;
		if (this->j == puntos_des.size()) {
			this->j = 0;
		}
		Vector v_d_1(centro, puntos_des[this->j]);
		v_d.vec = v_d_1.vec;
	}
	std::vector<int> GenerarRastro() {
		i_rastro.clear();
		for (int i = 0; i < rastro.size()/3; i++)
		{
			i_rastro.push_back(i);
		}
		return i_rastro;
	}
};
struct Marco {
	std::vector<float> vertices;
	std::vector<int> ind_line;
	int n_ind_line = 0;
	float scale = 1.0f;
	Marco(float k) {
		this->scale = k;
		for (int i = 1; i >= -1; i--)
		{
			for (int j = -1; j <= 1; j++)
			{
				this->vertices.push_back({ float(j) * this->scale});
				this->vertices.push_back({ float(i) * this->scale});
				this->vertices.push_back({ float(0.0f) * this->scale});
			}
		}
		int j[] = {0, 1, 1, 2, 3, 4, 4, 5, 6, 7, 7, 8, 0, 3, 3, 6, 1, 4, 4, 7, 2, 5, 5, 8};
		for (int i = 0; i < sizeof(j)/sizeof(int); i++)
		{
			ind_line.push_back(j[i]);
		}
		this->n_ind_line = ind_line.size();
	}
};
struct Animacion2D {
	std::vector<std::vector<float>> vec_ani;
	std::vector<float> vertices;
	std::vector<int> ind_p_ani;
	float scale = 0.0f;
	Animacion2D(int k,float scale) {
		this->scale = scale;
		if (k == 1) {
			Cuadrado();
		}
		if (k == 2) {
			Triangulo();
		}
		if (k == 3) {
			Circulo();
		}
		if (k == 4) {
			Rombo();
		}
	}
	void Cuadrado() {
		std::cout << std::endl;
		std::cout << "Cuadrado" << std::endl;
		vec_ani.push_back({-1.0f*this->scale,1.0f*this->scale,0.0f*this->scale});
		vec_ani.push_back({ 1.0f * this->scale,1.0f * this->scale,0.0f * this->scale });
		vec_ani.push_back({ 1.0f * this->scale,-1.0f * this->scale,0.0f * this->scale });
		vec_ani.push_back({ -1.0f * this->scale,-1.0f * this->scale,0.0f * this->scale });
		for (int i = 0; i < vec_ani.size(); i++)
		{
			ind_p_ani.push_back(i);
		}
	}
	void Triangulo() {
		std::cout << std::endl;
		std::cout << "Triangulo" << std::endl;
		vec_ani.push_back({ 0.0f * this->scale,1.0f * this->scale,0.0f * this->scale });
		vec_ani.push_back({ 1.0f * this->scale,-1.0f * this->scale,0.0f * this->scale });
		vec_ani.push_back({ -1.0f * this->scale,-1.0f * this->scale,0.0f * this->scale });
		for (int i = 0; i < vec_ani.size(); i++)
		{
			ind_p_ani.push_back(i);
		}
	}
	void Circulo() {
		std::cout << std::endl;
		std::cout << "Circulo" << std::endl;
		int n = 0;
		float r = 1;
		float tam = 10.0f;
		for (int i = 0; i < 80; i++)
		{
			if (n<180)
			{
				r += 0.2;
			}
			if (n>360)
			{
				n = 0;
			}
			vec_ani.push_back({ r * glm::cos(glm::radians(float(n))),
								r * glm::sin(glm::radians(float(n))),
								0.0f});
			n += 20;
		}
		for (int i = 0; i < vec_ani.size(); i++)
		{
			ind_p_ani.push_back(i);
		}
	}
	void Rombo() {
		std::cout << std::endl;
		std::cout << "Rombo" << std::endl;
		int n = 0;
		float r = 5;
		for (int i = 0; i < 4; i++)
		{
			vec_ani.push_back({ r * glm::cos(glm::radians(float(n))),
								r * glm::sin(glm::radians(float(n))),
								0.0f });
			n += 90;
		}
		for (int i = 0; i < vec_ani.size(); i++)
		{
			ind_p_ani.push_back(i);
		}
	}

	void Mover(std::vector<float>b) {
		std::vector<float> a = { 0.0f,0.0f,0.0f };
		std::vector<float> ba;
		for (int i = 0; i < a.size(); i++)
		{
			ba.push_back(b[i] - a[i]);
		}
		
		for (int i = 0; i < vec_ani.size(); i++)
		{
			vec_ani[i][0] += ba[0];
			vertices.push_back(vec_ani[i][0]);
			vec_ani[i][1] += ba[1];
			vertices.push_back(vec_ani[i][1]);
			vec_ani[i][2] += ba[2];
			vertices.push_back(vec_ani[i][2]);
		}

		//for (int i = 0; i < vertices.size(); i+=3)
		//{
		//	std::cout << vertices[i] << " " << vertices[i + 1] << " " << vertices[i + 2] << std::endl;
		//}
	}
};
void CargarVertices(std::vector<float> vertices) {
	glBufferData(GL_ARRAY_BUFFER,
		vertices.size() * sizeof(float),
		&vertices[0],
		GL_STATIC_DRAW);
}
void CargarIndices(std::vector<int> indices) {
	glBufferData(GL_ELEMENT_ARRAY_BUFFER,
		indices.size() * sizeof(int),
		&indices[0],
		GL_STATIC_DRAW);
}
std::vector<float> UnirVectores(std::vector<std::vector<float>> v) {
	std::vector<float> object_vertices;
	for (int i = 0; i < v.size(); i++)
	{
		for (int j = 0; j < v[i].size(); j++)
		{
			object_vertices.push_back(v[i][j]);
		}
	}
	return object_vertices;
}
std::vector<int> UnirIndicesT(std::vector<std::vector<int>> v) {
	std::vector<int> object_indices;
	int h = 0;
	for (int i = 0; i < v.size(); i++)
	{
		int tam = object_indices.size()/3 + h;
		for (int j = 0; j < v[i].size(); j++)
		{
			object_indices.push_back(v[i][j]+tam);
		}
		h++;
	}
	return object_indices;
}
std::vector<int> UnirIndicesP(std::vector<std::vector<int>> v) {
	std::vector<int> object_indices;
	int h = 0;
	for (int i = 0; i < v.size(); i++)
	{
		int tam = object_indices.size();
		for (int j = 0; j < v[i].size(); j++)
		{
			object_indices.push_back(v[i][j] + tam);
		}

	}
	return object_indices;
}
void PrimitivaColor(int c, unsigned int shaderProgram) {
	int vertexColorLocation = glGetUniformLocation(shaderProgram, "ourColor");
	if (c == 0) {
		glUniform4f(vertexColorLocation, 255.0f, 0.0f, 0.0f, 1.0f);
	}
	if (c == 1) {
		glUniform4f(vertexColorLocation, 0.0f, 255.0f, 0.0f, 1.0f);
	}
	if (c == 2) {
		glUniform4f(vertexColorLocation, 131.0f, 49.0f, 25.0f, 1.0f);
	}
	if (c == 3) {
		glUniform4f(vertexColorLocation, 255.0f, 0.0f, 255.0f, 1.0f);
	}
	if (c == 4) {
		glUniform4f(vertexColorLocation, 255.0f, 255.0f, 0.0f, 1.0f);
	}
}

void FondoColor(int c) {
	if (c == 1)
	{
		rValue = 12.0f;
		gValue = 12.0f;
		bValue = 12.0f;
	}
	else if (c == 2) {
		rValue = 2.0f;
		gValue = 122.0f;
		bValue = 42.0f;
	}
	else {
		rValue = 0.0f;
		gValue = 0.0f;
		bValue = 0.0f;
	}

	glClearColor(rValue, gValue, bValue, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT);
}
int main()
{
	// glfw: initialize and configure
	// ------------------------------
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3); // OpenGL 3.3
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE); // uncomment this statement to fix compilation on OS X
#endif

	// glfw window creation
	// --------------------
	GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "Basic OpenGL Program", NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
	glfwSetKeyCallback(window, key_callback);

	// glad: load all OpenGL function pointers
	// ---------------------------------------
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cout << "Failed to initialize GLAD" << std::endl;
		return -1;
	}

	//Vertex Shader
	unsigned int vertexShader = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(vertexShader, 1, &vertexShaderSource, NULL);
	glCompileShader(vertexShader);

	//Fragment Shader
	unsigned int fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragmentShader, 1, &fragmentShaderSource, NULL);
	glCompileShader(fragmentShader);

	//link Shaders
	unsigned int shaderProgram = glCreateProgram();
	glAttachShader(shaderProgram, vertexShader);
	glAttachShader(shaderProgram, fragmentShader);
	glLinkProgram(shaderProgram);

	glDeleteShader(vertexShader);
	glDeleteShader(fragmentShader);

	unsigned int VBO, VAO, EBO;
	glGenVertexArrays(1, &VAO);
	glGenBuffers(1, &VBO);
	glGenBuffers(1, &EBO);

	glBindVertexArray(VAO);
	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	glBindBuffer(GL_ARRAY_BUFFER, 0);

	glBindVertexArray(0);


	Marco marco(20);
	Animacion2D a_c(1,5.0f);
	a_c.Mover({ -10.0f,10.0f,0.0f });

	Animacion2D a_t(2, 5.0f);
	a_t.Mover({ 10.0f,10.0f,0.0f });

	Animacion2D a_e(3, 5.0f);
	a_e.Mover({ 10.0f,-10.0f,0.0f });

	Animacion2D a_r(4, 5.0f);
	a_r.Mover({ -10.0f,-10.0f,0.0f });
	
	Objeto2D cuadrado(4, 2, 0.01f, a_c.vec_ani);
	Objeto2D triangulo(3, 2, 0.01f, a_e.vec_ani);
	Objeto2D pentagono(5, 2, 0.01f, a_r.vec_ani);
	Objeto2D circulo(180, 2, 0.01f, a_t.vec_ani);

	//Primero juntar vertices
	std::vector<std::vector<float>> v_obj;
	v_obj.push_back(triangulo.vertices);
	v_obj.push_back(cuadrado.vertices);
	v_obj.push_back(pentagono.vertices);
	v_obj.push_back(circulo.vertices);
	std::vector<float> object_vertices = UnirVectores(v_obj);

	//Segundo juntamos indices
	std::vector<std::vector<int>> i_obj;
	i_obj.push_back(triangulo.i_p_t);
	i_obj.push_back(cuadrado.i_p_t);
	i_obj.push_back(pentagono.i_p_t);
	i_obj.push_back(circulo.i_p_t);
	std::vector<int> object_indices_triangulo = UnirIndicesT(i_obj);

	int num_obj_ind_t = object_indices_triangulo.size();
	std::vector<std::vector<float>> v_rastro;
	std::vector<std::vector<int>> i_rastro;
	while (!glfwWindowShouldClose(window))
	{

		// render
		FondoColor(0);

		// input
		processInput(window);
		glUseProgram(shaderProgram);
		glBindVertexArray(VAO);
		glBindBuffer(GL_ARRAY_BUFFER, VBO);

		//Dibujamos el Marco
		CargarVertices(marco.vertices);
		CargarIndices(marco.ind_line);
		PrimitivaColor(0, shaderProgram);
		glDrawElements(GL_LINES, marco.n_ind_line, GL_UNSIGNED_INT, 0);

		//Dibujamos Puntos de la Primera Animacion
		CargarVertices(a_c.vertices);
		CargarIndices(a_c.ind_p_ani);
		glPointSize(12.0f);
		PrimitivaColor(1, shaderProgram);
		glDrawElements(GL_POINTS,a_c.ind_p_ani.size(), GL_UNSIGNED_INT, 0);

		//Dibujamos Puntos de la Segunda Animacion
		CargarVertices(a_t.vertices);
		CargarIndices(a_t.ind_p_ani);
		glPointSize(12.0f);
		PrimitivaColor(1, shaderProgram);
		glDrawElements(GL_POINTS, a_t.ind_p_ani.size(), GL_UNSIGNED_INT, 0);

		//Dibujamos Puntos de la Tercera Animacion
		CargarVertices(a_e.vertices);
		CargarIndices(a_e.ind_p_ani);
		glPointSize(12.0f);
		PrimitivaColor(1, shaderProgram);
		glDrawElements(GL_POINTS, a_e.ind_p_ani.size(), GL_UNSIGNED_INT, 0);

		//Dibujamos Puntos de la Cuarta Animacion
		CargarVertices(a_r.vertices);
		CargarIndices(a_r.ind_p_ani);
		glPointSize(12.0f);
		PrimitivaColor(1, shaderProgram);
		glDrawElements(GL_POINTS, a_r.ind_p_ani.size(), GL_UNSIGNED_INT, 0);

		//New Code

		if (pausar)
		{
			cuadrado.Animacion();
			triangulo.Animacion();
			pentagono.Animacion();
			circulo.Animacion();
		}
		else {
			cuadrado.Manual(manual);
			triangulo.Manual(manual);
			pentagono.Manual(manual);
			circulo.Manual(manual);
			cuadrado.Restaurar();
			triangulo.Restaurar();
			pentagono.Restaurar();
			circulo.Restaurar();
		}

		object_vertices.clear();
		v_obj.clear();
		v_obj.push_back(triangulo.vertices);
		v_obj.push_back(cuadrado.vertices);
		v_obj.push_back(pentagono.vertices);
		v_obj.push_back(circulo.vertices);
		object_vertices.clear();
		object_vertices = UnirVectores(v_obj);


		if (camino) {
			//Dibujaremos un Rastro
			v_rastro.clear();
			v_rastro.push_back(triangulo.rastro);
			v_rastro.push_back(circulo.rastro);
			v_rastro.push_back(cuadrado.rastro);
			v_rastro.push_back(pentagono.rastro);
			i_rastro.push_back(triangulo.GenerarRastro());
			i_rastro.push_back(circulo.GenerarRastro());
			i_rastro.push_back(cuadrado.GenerarRastro());
			i_rastro.push_back(pentagono.GenerarRastro());
			CargarVertices(UnirVectores(v_rastro));
			std::vector<int> i_r = UnirIndicesP(i_rastro);
			CargarIndices(i_r);
			PrimitivaColor(2, shaderProgram);
			glPointSize(10.0f);
			glDrawElements(GL_POINTS, i_r.size(), GL_UNSIGNED_INT, 0);
		}
		//Dibujamos los Objetos
		CargarVertices(object_vertices);
		CargarIndices(object_indices_triangulo);
		PrimitivaColor(3, shaderProgram);
		glDrawElements(GL_TRIANGLES, num_obj_ind_t, GL_UNSIGNED_INT, 0);	

		//system("pause");
		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	glfwTerminate();
	return 0;
}

// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
// ---------------------------------------------------------------------------------------------------------
void processInput(GLFWwindow* window)
{
	//if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
	//	glfwSetWindowShouldClose(window, true);

}

// glfw: whenever the window size changed (by OS or user resize) this callback function executes
// ---------------------------------------------------------------------------------------------
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
	// make sure the viewport matches the new window dimensions; note that width and 
	// height will be significantly larger than specified on retina displays.
	glViewport(0, 0, width, height);
}

void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	if (glfwGetKey(window, GLFW_KEY_DOWN) == GLFW_PRESS)
	{
		if (velocidad > 0.01f)
		{
			velocidad -= 0.01f;
		}
	}
	if (glfwGetKey(window, GLFW_KEY_UP) == GLFW_PRESS)
	{
		if (velocidad < 0.09f)
		{
			velocidad += 0.01f;
		}
	}
	if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS)
	{
		camino = true;
	}
	if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS)
	{
		camino = false;
	}
	if (glfwGetKey(window, GLFW_KEY_RIGHT_CONTROL) == GLFW_PRESS)
	{
		pausar = false;
	}
	if (glfwGetKey(window, GLFW_KEY_LEFT_CONTROL) == GLFW_PRESS)
	{
		pausar = true;
		manual = { 0.0f,0.0f,0.0f };
	}
	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
	{
		manual = { 0.0f,1.0f,0.0f };
	}
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
	{
		manual = { 0.0f,-1.0f,0.0f };
	}
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
	{
		manual = { 1.0f,0.0f,0.0f };
	}
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) 
	{
		manual = { -1.0f,0.0f,0.0f };
	}
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);
}
