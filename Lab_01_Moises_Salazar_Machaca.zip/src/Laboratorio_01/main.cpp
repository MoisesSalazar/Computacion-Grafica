//Moises Alberto Salazar Machaca
//Computaci�n Gr�fica - CCOMP7-1

#include <glad/glad.h>
#include <glfw/glfw3.h>
#include <cstdlib>
#include <iostream>
#include <math.h>
#include <vector>
void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods);
void processInput(GLFWwindow *window);

// settings
const unsigned int SCR_WIDTH = 1000;
const unsigned int SCR_HEIGHT = 1000;

float rValue = 0.0f, gValue = 0.0f, bValue = 0.0f;
int primitiva = 0;

const char* vertexShaderSource = "#version 330 core\n"
"layout (location = 0) in vec3 aPos;\n"
"void main()\n"
"{\n"
"   gl_Position = vec4(aPos.x, aPos.y, aPos.z, 30.0);\n"
"}\0";

const char* fragmentShaderSource = "#version 330 core\n"
"out vec4 FragColor;\n"
"void main()\n"
"{\n"
"   FragColor = vec4(1.0f, 0.5f, 0.2f, 1.0f);\n"
"}\n\0";

int main()
{
	// glfw: initialize and configure
	// ------------------------------
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3); // OpenGL 3.3
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE); // uncomment this statement to fix compilation on OS X
#endif

	// glfw window creation
	// --------------------
	GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "Basic OpenGL Program", NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
	glfwSetKeyCallback(window, key_callback);

	// glad: load all OpenGL function pointers
	// ---------------------------------------
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cout << "Failed to initialize GLAD" << std::endl;
		return -1;
	}

	//Vertex Shader
	unsigned int vertexShader = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(vertexShader, 1, &vertexShaderSource, NULL);
	glCompileShader(vertexShader);

	//Fragment Shader
	unsigned int fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragmentShader, 1, &fragmentShaderSource, NULL);
	glCompileShader(fragmentShader);

	//link Shaders
	unsigned int shaderProgram = glCreateProgram();
	glAttachShader(shaderProgram, vertexShader);
	glAttachShader(shaderProgram, fragmentShader);
	glLinkProgram(shaderProgram);

	glDeleteShader(vertexShader);
	glDeleteShader(fragmentShader);

	//Casita
	float v_casa[] = {
		// triangulo
		0.00f,  15.00f,   0.00f, //centro
		-15.00f,    5.00f,  0.00f,
		15.00f, 5.00f,  0.00f,
		// cuadrado
		-5.00f,    5.00f,  0.00f,
		5.00f, 5.00f,  0.00f,
		5.00f, -5.00f,  0.00f,
		-5.00f,    -5.00f,  0.00f,
	};
	int i_p_casa[] = {
		0,  1,  2,	3,  4,  5,	6
	};
	int i_l_casa[] = {
		1,0,0,2,1,3,2,4,4,5,5,6,3,6
	};
	int i_t_casa[] = {
		0,  1,  2,	3,  4,  5,	3,  5,  6
	};

	//Estrella
	float v_estrella[] = {
		// pentagono
		0.00f,  0.00f,   0.00f, //centro
		-5.88f,  8.09f,  0.00f,
		5.99f,  8.09f,  0.00f,
		9.51f,  -3.09f, 0.00f,
		0.00f,  -10.00f,    0.00f,
		-9.51f, -3.09,  0.00f,
		//triangulos de lados del pentagono
		0.00f,  26.18f, 0.00f,
		24.6f,  8.09f,  0.00f,
		15.39f, -21.18f,    0.00f,
		-15.39f, -21.18f,    0.00f,
		-24.6f,  8.09f,  0.00f,
	};
	int i_t_estrella[] = {
		0,  1,  2,
		0,  2,  3,
		0,  3,  4,
		0,  4,  5,
		0,  5,  1,
		1,  2,  6,
		2,  3,  7,
		3,  4,  8,
		4,  5,  9,
		5,  1,  10
	};
	int i_p_estrella[] = {
		1,2,3,4,5,6,7,8,9,10
	};
	int i_l_estrella[] = {
		1,6,6,2,2,7,7,3,3,8,8,4,4,9,9,5,5,10,10,1
	};

	//Pizza

	int radio = 10;
	int angulo = 9;
	int angulo1 = 0;
	int triangulos = 360 / angulo;
	std::vector<float> v_pizza;
	v_pizza.push_back(0.00f);
	v_pizza.push_back(0.00f);
	v_pizza.push_back(0.00f);
	
	while (360>=angulo1)
	{
		std::cout << angulo1 << std::endl;
		v_pizza.push_back(radio * cos(angulo1 * 3.14 / 180));
		v_pizza.push_back(radio * sin(angulo1 * 3.14 / 180));
		v_pizza.push_back(0.00f);
		angulo1 += angulo;
	}

	std::vector<int>i_p_pizza;
	for (int i = 0; i < v_pizza.size(); i++)
	{
		i_p_pizza.push_back(i);
	}

	std::vector<int>i_t_pizza;
	for (int i = 0; i < v_pizza.size(); i++)
	{
		i_t_pizza.push_back(0);
		i_t_pizza.push_back(i);
		i_t_pizza.push_back(i + 1);
	}
	std::vector<int>i_l_pizza;
	//Circunferencia
	for (int i = 1; i < v_pizza.size() / 3 - 1; i++)
	{
		i_l_pizza.push_back(i);
		i_l_pizza.push_back(i+1);
	}
	//Tajadas

	angulo1 = 0;
	int i = 1;
	while (360 >= angulo1)
	{
		i_l_pizza.push_back(0);
		i_l_pizza.push_back(i);
		i += 4;
		angulo1 += angulo;
	}

	unsigned int VBO, VAO, EBO;
	glGenVertexArrays(1, &VAO);
	glGenBuffers(1, &VBO);
	glGenBuffers(1, &EBO);

	glBindVertexArray(VAO);

	glBindBuffer(GL_ARRAY_BUFFER, VBO);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(i_l_casa), i_l_casa, GL_STATIC_DRAW);

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	glBindBuffer(GL_ARRAY_BUFFER, 0);

	glBindVertexArray(0);
	
	// render loop
	// -----------
	while (!glfwWindowShouldClose(window))
	{

		// render
		glClearColor(rValue, gValue, bValue, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT);

		// input
		processInput(window);
		glUseProgram(shaderProgram);
		glBindVertexArray(VAO);
		glBindBuffer(GL_ARRAY_BUFFER, VBO);


		if (primitiva == 1)
		{
			glBufferData(GL_ARRAY_BUFFER, sizeof(v_casa), v_casa, GL_STATIC_DRAW);
			int frame = 900;
			while (frame) {
				// render
				glClearColor(rValue, gValue, bValue, 1.0f);
				glClear(GL_COLOR_BUFFER_BIT);

				// input
				processInput(window);
				glUseProgram(shaderProgram);
				glBindVertexArray(VAO);
				if (frame < 300) {
					//rValue =255.0f; gValue = 0.0f; bValue = 0.0f;
					glPointSize(10.00f);
					glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(i_p_casa), i_p_casa, GL_STATIC_DRAW);
					glDrawElements(GL_POINTS, 7, GL_UNSIGNED_INT, 0);
				}
				else if (frame < 600) {
					//rValue = 0.0f; gValue = 255.0f; bValue = 0.0f;
					glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(i_l_casa), i_l_casa, GL_STATIC_DRAW);
					glDrawElements(GL_LINES, 14, GL_UNSIGNED_INT, 0);
				}
				else {
					//rValue = 0.0f; gValue = 0.0f; bValue = 255.0f;
					glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(i_t_casa), i_t_casa, GL_STATIC_DRAW);
					glDrawElements(GL_TRIANGLES, 9, GL_UNSIGNED_INT, 0);
				}
				glfwSwapBuffers(window);
				glfwPollEvents();
				frame -= 1;
			}
		}
		else if (primitiva == 2) {
			glBufferData(GL_ARRAY_BUFFER, sizeof(v_estrella), v_estrella, GL_STATIC_DRAW);
			int frame = 900;
			while (frame) {
				// render
				glClearColor(rValue, gValue, bValue, 1.0f);
				glClear(GL_COLOR_BUFFER_BIT);

				// input
				processInput(window);
				glUseProgram(shaderProgram);
				glBindVertexArray(VAO);
				if (frame < 300) {
					//rValue =255.0f; gValue = 0.0f; bValue = 0.0f;
					glPointSize(10.00f);
					glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(i_p_estrella), i_p_estrella, GL_STATIC_DRAW);
					glDrawElements(GL_POINTS, 10, GL_UNSIGNED_INT, 0);
				}
				else if (frame < 600) {
					//rValue = 0.0f; gValue = 255.0f; bValue = 0.0f;
					glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(i_l_estrella), i_l_estrella, GL_STATIC_DRAW);
					glDrawElements(GL_LINES, 20, GL_UNSIGNED_INT, 0);
				}
				else {
					//rValue = 0.0f; gValue = 0.0f; bValue = 255.0f;
					glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(i_t_estrella), i_t_estrella, GL_STATIC_DRAW);
					glDrawElements(GL_TRIANGLES, 30, GL_UNSIGNED_INT, 0);
				}
				glfwSwapBuffers(window);
				glfwPollEvents();
				frame -= 1;
			}

		}
		else if (primitiva == 3) {
			glBufferData(GL_ARRAY_BUFFER, v_pizza.size()*sizeof(float), &v_pizza[0], GL_STATIC_DRAW);
			int frame = 900;
			while (frame) {
				// render
				glClearColor(rValue, gValue, bValue, 1.0f);
				glClear(GL_COLOR_BUFFER_BIT);

				// input
				processInput(window);
				glUseProgram(shaderProgram);
				glBindVertexArray(VAO);
				
				if (frame < 300) {
					//rValue =255.0f; gValue = 0.0f; bValue = 0.0f;
					glPointSize(10.00f);
					glBufferData(GL_ELEMENT_ARRAY_BUFFER, i_p_pizza.size() * sizeof(int), &i_p_pizza[0], GL_STATIC_DRAW);
					glDrawElements(GL_POINTS, i_p_pizza.size(), GL_UNSIGNED_INT, 0);

				}
				else if (frame < 600) {
					glBufferData(GL_ELEMENT_ARRAY_BUFFER, i_l_pizza.size() * sizeof(int), &i_l_pizza[0], GL_STATIC_DRAW);
					glDrawElements(GL_LINES, i_l_pizza.size(), GL_UNSIGNED_INT, 0);

				}
				else {
					//rValue = 0.0f; gValue = 0.0f; bValue = 255.0f;
					glBufferData(GL_ELEMENT_ARRAY_BUFFER, i_t_pizza.size() * sizeof(int), &i_t_pizza[0], GL_STATIC_DRAW);
					glDrawElements(GL_TRIANGLES, i_t_pizza.size(), GL_UNSIGNED_INT, 0);
				}

				glfwSwapBuffers(window);
				glfwPollEvents();
				frame -= 1;
			}

		}

		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	glfwTerminate();
	return 0;
}

// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
// ---------------------------------------------------------------------------------------------------------
void processInput(GLFWwindow *window)
{
	//if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
	//	glfwSetWindowShouldClose(window, true);
	
}

// glfw: whenever the window size changed (by OS or user resize) this callback function executes
// ---------------------------------------------------------------------------------------------
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
	// make sure the viewport matches the new window dimensions; note that width and 
	// height will be significantly larger than specified on retina displays.
	glViewport(0, 0, width, height);
}

void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	if (glfwGetKey(window, GLFW_KEY_C) == GLFW_PRESS)
	{
		primitiva = 1;
	}

	if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
	{
		primitiva = 2;
	}

	if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
	{
		primitiva = 3;
	}

	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);
}
